package com.evoragx.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.speech.RecognizerIntent
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    // Buraya, GitHub'da repo olusturduktan sonra bir "version.json" dosyasi barindirirsan
    // (ornek: https://raw.githubusercontent.com/kullaniciadi/evora-gx/main/version.json)
    // onun raw linkini yazarsan uygulama acilista guncelleme kontrolu yapar. Bos birakirsan hicbir sey yapmaz.
    private val UPDATE_CHECK_URL = ""

    private val HOME_URL = "file:///android_asset/home.html"

    private val AD_BLOCK_DOMAINS = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "ads.yahoo.com", "adnxs.com", "taboola.com",
        "outbrain.com", "criteo.com", "moatads.com", "scorecardresearch.com",
        "adsafeprotected.com", "popads.net", "exoclick.com", "propellerads.com",
        "adcolony.com", "unityads.unity3d.com", "mopub.com"
    )

    private data class TabData(
        val webView: WebView,
        val chipView: View,
        var title: String = "Yeni sekme",
        var url: String = ""
    )

    private lateinit var tabsLayout: LinearLayout
    private lateinit var webViewContainer: ViewGroup
    private lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar

    private lateinit var historyPrefs: SharedPreferences
    private lateinit var bookmarkPrefs: SharedPreferences
    private lateinit var settingsPrefs: SharedPreferences

    private val tabs = mutableListOf<TabData>()
    private var activeTabIndex = -1

    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                addressBar.setText(spoken)
                navigate()
            }
        }
    }

    private val micPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVoiceRecognition() else toast("Sesle aramak için mikrofon izni gerekiyor")
    }

    private val notifPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) toast("Bildirimler açık")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val earlyPrefs = getSharedPreferences("evora_settings", MODE_PRIVATE)
        AppCompatDelegate.setDefaultNightMode(
            if (earlyPrefs.getString("theme", "dark") == "light") AppCompatDelegate.MODE_NIGHT_NO
            else AppCompatDelegate.MODE_NIGHT_YES
        )
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        historyPrefs = getSharedPreferences("evora_history", MODE_PRIVATE)
        bookmarkPrefs = getSharedPreferences("evora_bookmarks", MODE_PRIVATE)
        settingsPrefs = getSharedPreferences("evora_settings", MODE_PRIVATE)

        tabsLayout = findViewById(R.id.tabsLayout)
        webViewContainer = findViewById(R.id.webViewContainer)
        addressBar = findViewById(R.id.addressBar)
        progressBar = findViewById(R.id.progressBar)

        val btnBack: ImageButton = findViewById(R.id.btnBack)
        val btnForward: ImageButton = findViewById(R.id.btnForward)
        val btnReload: ImageButton = findViewById(R.id.btnReload)
        val btnGo: ImageButton = findViewById(R.id.btnGo)
        val btnSettings: ImageButton = findViewById(R.id.btnSettings)
        val btnMenu: ImageButton = findViewById(R.id.btnMenu)
        val btnNewTab: ImageButton = findViewById(R.id.btnNewTab)

        btnBack.setOnClickListener { currentTab()?.let { if (it.webView.canGoBack()) it.webView.goBack() } }
        btnForward.setOnClickListener { currentTab()?.let { if (it.webView.canGoForward()) it.webView.goForward() } }
        btnReload.setOnClickListener { currentTab()?.webView?.reload() }
        btnGo.setOnClickListener { navigate() }
        btnNewTab.setOnClickListener { createNewTab(HOME_URL) }
        btnSettings.setOnClickListener { showSettingsDialog() }
        btnMenu.setOnClickListener { showOverflowMenu(it) }

        addressBar.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val drawableStart = addressBar.compoundDrawables[0]
                if (drawableStart != null && event.rawX <= (addressBar.left + drawableStart.bounds.width() + addressBar.paddingStart + 40)) {
                    onMicClicked()
                    return@setOnTouchListener true
                }
            }
            false
        }

        applyTextZoom()

        addressBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                navigate()
                true
            } else {
                false
            }
        }

        createNewTab(HOME_URL)

        val followPrefs = getSharedPreferences(MatchCheckWorker.PREFS_NAME, MODE_PRIVATE)
        if (!followPrefs.getString("team_name", "").isNullOrEmpty()) {
            scheduleMatchChecks()
        }

        checkForUpdate()
    }

    // ---------------- Sekme yonetimi ----------------

    private fun currentTab(): TabData? = tabs.getOrNull(activeTabIndex)

    @SuppressLint("SetJavaScriptEnabled")
    private fun createNewTab(url: String) {
        val webView = WebView(this)
        webView.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.setSupportZoom(true)
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false
        webView.settings.textZoom = when (settingsPrefs.getString("fontSize", "medium")) {
            "small" -> 85; "large" -> 130; else -> 100
        }
        if (settingsPrefs.getBoolean("desktopMode", false)) {
            webView.settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
        }
        webView.addJavascriptInterface(WebAppInterface(), "Android")

        val chip = LayoutInflater.from(this).inflate(R.layout.tab_item, tabsLayout, false)
        val tab = TabData(webView, chip)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "evora-search") {
                    val query = Uri.decode(uri.schemeSpecificPart.removePrefix("//"))
                    webView.loadUrl(searchEngineUrl(query))
                    return true
                }
                return false
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (!settingsPrefs.getBoolean("adBlock", true)) return super.shouldInterceptRequest(view, request)
                val host = request?.url?.host ?: return super.shouldInterceptRequest(view, request)
                val blocked = AD_BLOCK_DOMAINS.any { host.contains(it) }
                return if (blocked) {
                    WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                } else {
                    super.shouldInterceptRequest(view, request)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                tab.url = url ?: tab.url
                val isHome = tab.url == HOME_URL
                if (tabs.getOrNull(activeTabIndex) === tab) addressBar.setText(if (isHome) "" else tab.url)
                if (isHome) {
                    tab.title = "Yeni sekme"
                    chip.findViewById<TextView>(R.id.tabTitle).text = tab.title
                }
                if (url != null && !isHome) saveHistory(url)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                if (tabs.getOrNull(activeTabIndex) === tab) {
                    if (newProgress in 1..99) {
                        progressBar.visibility = View.VISIBLE
                        progressBar.progress = newProgress
                    } else {
                        progressBar.visibility = View.GONE
                    }
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                if (tab.url == HOME_URL) return
                tab.title = title ?: tab.title
                chip.findViewById<TextView>(R.id.tabTitle).text = tab.title
                if (title != null) updateHistoryTitle(tab.url, title)
            }
        }

        webView.setDownloadListener { dUrl, userAgent, contentDisposition, mimetype, _ ->
            try {
                val fileName = URLUtil.guessFileName(dUrl, contentDisposition, mimetype)
                val request = DownloadManager.Request(Uri.parse(dUrl))
                request.setMimeType(mimetype)
                val cookie = CookieManager.getInstance().getCookie(dUrl)
                request.addRequestHeader("cookie", cookie)
                request.addRequestHeader("User-Agent", userAgent)
                request.setTitle(fileName)
                request.setDescription("Evora GX ile indiriliyor")
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                toast("İndirme başladı: $fileName")
            } catch (e: Exception) {
                toast("İndirme başlatılamadı")
            }
        }

        chip.findViewById<TextView>(R.id.tabTitle).text = tab.title
        chip.setOnClickListener { switchToTab(tabs.indexOf(tab)) }
        chip.findViewById<View>(R.id.tabClose).setOnClickListener { closeTab(tabs.indexOf(tab)) }

        tabs.add(tab)
        tabsLayout.addView(chip)
        webViewContainer.addView(webView)

        switchToTab(tabs.size - 1)
        webView.loadUrl(url)
    }

    private fun switchToTab(index: Int) {
        if (index !in tabs.indices) return
        activeTabIndex = index
        tabs.forEachIndexed { i, t ->
            t.webView.visibility = if (i == index) View.VISIBLE else View.GONE
            updateTabChipStyle(t, i == index)
        }
        addressBar.setText(if (tabs[index].url == HOME_URL) "" else tabs[index].url)
    }

    private fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        if (settingsPrefs.getBoolean("confirmClose", false)) {
            AlertDialog.Builder(this)
                .setMessage("Bu sekmeyi kapatmak istediğine emin misin?")
                .setPositiveButton("Kapat") { _, _ -> performCloseTab(index) }
                .setNegativeButton("Vazgeç", null)
                .show()
        } else {
            performCloseTab(index)
        }
    }

    private fun performCloseTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs[index]
        webViewContainer.removeView(tab.webView)
        tabsLayout.removeView(tab.chipView)
        tab.webView.destroy()
        tabs.removeAt(index)

        if (tabs.isEmpty()) {
            createNewTab("https://www.google.com")
            return
        }
        val newIndex = if (index >= tabs.size) tabs.size - 1 else index
        switchToTab(newIndex)
    }

    // ---------------- Adres cubugu / navigasyon ----------------

    private fun navigate() {
        val tab = currentTab() ?: return
        val input = addressBar.text.toString().trim()
        if (input.isEmpty()) return
        val looksLikeUrl = input.startsWith("http://") || input.startsWith("https://") ||
            Regex("^[\\w-]+(\\.[\\w-]+)+.*$").matches(input)
        val url = when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            looksLikeUrl -> "https://$input"
            else -> searchEngineUrl(input)
        }
        tab.webView.loadUrl(url)
    }

    // ---------------- Sesle arama ----------------

    private inner class WebAppInterface {
        @JavascriptInterface
        fun startVoice() {
            runOnUiThread { onMicClicked() }
        }
    }

    private fun onMicClicked() {
        val hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) startVoiceRecognition() else micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Konuş...")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            toast("Cihazında sesle arama desteklenmiyor")
        }
    }

    // ---------------- Gecmis ----------------

    private fun saveHistory(url: String) {
        val existing = historyPrefs.getString("list", "") ?: ""
        val entries = existing.split("||").filter { it.isNotBlank() }.toMutableList()
        entries.removeAll { it.substringAfterLast("::", "") == url }
        entries.add(0, "$url::$url")
        historyPrefs.edit().putString("list", entries.take(200).joinToString("||")).apply()
    }

    private fun updateHistoryTitle(url: String, title: String) {
        val existing = historyPrefs.getString("list", "") ?: ""
        val entries = existing.split("||").filter { it.isNotBlank() }.toMutableList()
        val idx = entries.indexOfFirst { it.substringAfterLast("::", "") == url }
        if (idx >= 0 && title.isNotBlank()) {
            entries[idx] = "$title::$url"
            historyPrefs.edit().putString("list", entries.joinToString("||")).apply()
        }
    }

    private fun showHistoryDialog() {
        val entries = (historyPrefs.getString("list", "") ?: "").split("||").filter { it.isNotBlank() }
        if (entries.isEmpty()) {
            toast("Henüz geçmiş yok")
            return
        }
        val titles = entries.map { it.substringBeforeLast("::", it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Geçmiş")
            .setItems(titles) { _, which ->
                val url = entries[which].substringAfterLast("::", "")
                if (url.isNotBlank()) currentTab()?.webView?.loadUrl(url)
            }
            .setNegativeButton("Kapat", null)
            .setNeutralButton("Temizle") { _, _ ->
                historyPrefs.edit().clear().apply()
            }
            .show()
    }

    // ---------------- Yer imleri ----------------

    private fun isBookmarked(url: String): Boolean {
        val list = bookmarkPrefs.getString("list", "") ?: ""
        return list.split("||").any { it.substringAfterLast("::", "") == url }
    }

    private fun toggleBookmark(url: String, title: String) {
        val existing = bookmarkPrefs.getString("list", "") ?: ""
        var entries = existing.split("||").filter { it.isNotBlank() }.toMutableList()
        val already = entries.find { it.substringAfterLast("::", "") == url }
        if (already != null) {
            entries.remove(already)
            toast("Yer imlerinden kaldırıldı")
        } else {
            entries.add(0, "$title::$url")
            toast("Yer imlerine eklendi")
        }
        bookmarkPrefs.edit().putString("list", entries.joinToString("||")).apply()
    }

    private fun showBookmarksDialog() {
        val entries = (bookmarkPrefs.getString("list", "") ?: "").split("||").filter { it.isNotBlank() }
        if (entries.isEmpty()) {
            toast("Henüz yer imi yok")
            return
        }
        val titles = entries.map { it.substringBeforeLast("::", it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Yer İmleri")
            .setItems(titles) { _, which ->
                val url = entries[which].substringAfterLast("::", "")
                if (url.isNotBlank()) currentTab()?.webView?.loadUrl(url)
            }
            .setNegativeButton("Kapat", null)
            .setNeutralButton("Tümünü sil") { _, _ ->
                bookmarkPrefs.edit().clear().apply()
            }
            .show()
    }

    // ---------------- Paylas ----------------

    private fun shareCurrentPage() {
        val url = currentTab()?.url ?: return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, url)
        }
        startActivity(Intent.createChooser(intent, "Paylaş"))
    }

    // ---------------- Mac takibi ----------------

    private fun showFollowDialog() {
        val followPrefs = getSharedPreferences(MatchCheckWorker.PREFS_NAME, MODE_PRIVATE)
        val current = followPrefs.getString("team_name", "") ?: ""

        val input = EditText(this)
        input.setText(current)
        input.hint = "Örn: Galatasaray, Real Madrid..."

        AlertDialog.Builder(this)
            .setTitle("Maç takip et")
            .setMessage("Takip etmek istediğin takımı yaz. 15 dakikada bir kontrol edilip, maç başladığında veya skor değiştiğinde bildirim gelir.")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val teamName = input.text.toString().trim()
                if (teamName.isEmpty()) return@setPositiveButton
                followPrefs.edit().putString("team_name", teamName).apply()
                ensureNotificationPermission()
                scheduleMatchChecks()
                toast("$teamName takip ediliyor")
            }
            .setNeutralButton("Takibi bırak") { _, _ ->
                followPrefs.edit().clear().apply()
                WorkManager.getInstance(this).cancelUniqueWork("match_check_work")
                toast("Takip iptal edildi")
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun ensureNotificationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (!granted) notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun scheduleMatchChecks() {
        val request = PeriodicWorkRequestBuilder<MatchCheckWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "match_check_work", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }

    // ---------------- Ayarlar ----------------

    private fun searchEngineUrl(query: String): String {
        val engine = settingsPrefs.getString("engine", "google")
        val base = when (engine) {
            "bing" -> "https://www.bing.com/search?q="
            "duckduckgo" -> "https://duckduckgo.com/?q="
            "yandex" -> "https://yandex.com/search/?text="
            else -> "https://www.google.com/search?q="
        }
        return base + URLEncoder.encode(query, "UTF-8")
    }

    private fun applyTextZoom() {
        val size = settingsPrefs.getString("fontSize", "medium")
        val zoom = when (size) { "small" -> 85; "large" -> 130; else -> 100 }
        tabs.forEach { it.webView.settings.textZoom = zoom }
    }

    private fun getAccentColor(): Int {
        val hex = settingsPrefs.getString("accent", "#E5484D") ?: "#E5484D"
        return try { android.graphics.Color.parseColor(hex) } catch (e: Exception) { android.graphics.Color.parseColor("#E5484D") }
    }

    private fun applyAccent() {
        val color = getAccentColor()
        progressBar.progressTintList = android.content.res.ColorStateList.valueOf(color)
        tabs.getOrNull(activeTabIndex)?.let { updateTabChipStyle(it, true) }
        tabs.forEachIndexed { i, t -> updateTabChipStyle(t, i == activeTabIndex) }
    }

    private fun updateTabChipStyle(tab: TabData, active: Boolean) {
        val bg = android.graphics.drawable.GradientDrawable()
        bg.cornerRadius = 8f * resources.displayMetrics.density
        bg.setColor(ContextCompat.getColor(this, if (active) R.color.bg_tab_active else R.color.bg_tab))
        bg.setStroke(
            (1 * resources.displayMetrics.density).toInt(),
            if (active) getAccentColor() else ContextCompat.getColor(this, R.color.border)
        )
        tab.chipView.background = bg
    }

    private fun showSettingsDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_settings, null)
        val themeGroup = view.findViewById<RadioGroup>(R.id.themeGroup)
        val engineGroup = view.findViewById<RadioGroup>(R.id.engineGroup)
        val fontGroup = view.findViewById<RadioGroup>(R.id.fontGroup)
        val confirmCloseCheck = view.findViewById<android.widget.CheckBox>(R.id.confirmCloseCheck)
        val adBlockCheck = view.findViewById<android.widget.CheckBox>(R.id.adBlockCheck)
        val desktopModeCheck = view.findViewById<android.widget.CheckBox>(R.id.desktopModeCheck)
        val colorContainer = view.findViewById<LinearLayout>(R.id.colorContainer)

        themeGroup.check(if (settingsPrefs.getString("theme", "dark") == "light") R.id.themeLight else R.id.themeDark)

        val engineIdMap = mapOf(
            "google" to R.id.engineGoogle, "bing" to R.id.engineBing,
            "duckduckgo" to R.id.engineDuck, "yandex" to R.id.engineYandex
        )
        engineGroup.check(engineIdMap[settingsPrefs.getString("engine", "google")] ?: R.id.engineGoogle)

        val fontIdMap = mapOf("small" to R.id.fontSmall, "medium" to R.id.fontMedium, "large" to R.id.fontLarge)
        fontGroup.check(fontIdMap[settingsPrefs.getString("fontSize", "medium")] ?: R.id.fontMedium)

        confirmCloseCheck.isChecked = settingsPrefs.getBoolean("confirmClose", false)
        adBlockCheck.isChecked = settingsPrefs.getBoolean("adBlock", true)
        desktopModeCheck.isChecked = settingsPrefs.getBoolean("desktopMode", false)

        val colors = listOf("#E5484D", "#7B2FF7", "#FF2E88", "#00C2FF", "#00E08F", "#FF9500")
        var selectedColor = settingsPrefs.getString("accent", "#E5484D")
        val dots = mutableListOf<View>()
        colors.forEach { hex ->
            val dot = View(this)
            val size = (32 * resources.displayMetrics.density).toInt()
            val params = LinearLayout.LayoutParams(size, size)
            params.marginEnd = (10 * resources.displayMetrics.density).toInt()
            dot.layoutParams = params
            val shape = android.graphics.drawable.GradientDrawable()
            shape.shape = android.graphics.drawable.GradientDrawable.OVAL
            shape.setColor(android.graphics.Color.parseColor(hex))
            shape.setStroke((2 * resources.displayMetrics.density).toInt(), if (hex == selectedColor) android.graphics.Color.WHITE else android.graphics.Color.TRANSPARENT)
            dot.background = shape
            dot.setOnClickListener {
                selectedColor = hex
                dots.forEachIndexed { i, d ->
                    val s = d.background as android.graphics.drawable.GradientDrawable
                    s.setStroke((2 * resources.displayMetrics.density).toInt(), if (colors[i] == hex) android.graphics.Color.WHITE else android.graphics.Color.TRANSPARENT)
                }
            }
            dots.add(dot)
            colorContainer.addView(dot)
        }

        AlertDialog.Builder(this)
            .setTitle("Ayarlar")
            .setView(view)
            .setPositiveButton("Kaydet") { _, _ ->
                val engineKey = engineIdMap.entries.find { it.value == engineGroup.checkedRadioButtonId }?.key ?: "google"
                val fontKey = fontIdMap.entries.find { it.value == fontGroup.checkedRadioButtonId }?.key ?: "medium"
                val themeKey = if (themeGroup.checkedRadioButtonId == R.id.themeLight) "light" else "dark"
                val themeChanged = themeKey != settingsPrefs.getString("theme", "dark")
                val desktopChanged = desktopModeCheck.isChecked != settingsPrefs.getBoolean("desktopMode", false)

                settingsPrefs.edit()
                    .putString("engine", engineKey)
                    .putString("fontSize", fontKey)
                    .putString("accent", selectedColor)
                    .putString("theme", themeKey)
                    .putBoolean("confirmClose", confirmCloseCheck.isChecked)
                    .putBoolean("adBlock", adBlockCheck.isChecked)
                    .putBoolean("desktopMode", desktopModeCheck.isChecked)
                    .apply()

                applyTextZoom()
                applyAccent()

                if (desktopChanged) applyDesktopMode()

                if (themeChanged) {
                    AppCompatDelegate.setDefaultNightMode(
                        if (themeKey == "light") AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
                    )
                    recreate()
                } else {
                    toast("Ayarlar kaydedildi")
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun applyDesktopMode() {
        val desktop = settingsPrefs.getBoolean("desktopMode", false)
        val desktopUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
        tabs.forEach { tab ->
            tab.webView.settings.userAgentString = if (desktop) desktopUA else null
            if (tab.url != HOME_URL) tab.webView.reload()
        }
    }

    // ---------------- Guncelleme kontrolu ----------------

    private fun checkForUpdate() {
        if (UPDATE_CHECK_URL.isBlank()) return
        Thread {
            try {
                val conn = URL(UPDATE_CHECK_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(text)
                val remoteVersion = json.optInt("versionCode", -1)
                val downloadUrl = json.optString("downloadUrl", "")
                val localVersion = packageManager.getPackageInfo(packageName, 0).let {
                    @Suppress("DEPRECATION") it.versionCode
                }
                if (remoteVersion > localVersion && downloadUrl.isNotBlank()) {
                    runOnUiThread {
                        AlertDialog.Builder(this)
                            .setTitle("Güncelleme var")
                            .setMessage("Evora GX'in yeni bir sürümü hazır. İndirmek ister misin?")
                            .setPositiveButton("İndir") { _, _ ->
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(downloadUrl)))
                            }
                            .setNegativeButton("Daha sonra", null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                // sessizce yoksay, guncelleme kontrolu kritik degil
            }
        }.start()
    }

    // ---------------- Ust menu ----------------

    private fun showOverflowMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        val url = currentTab()?.url ?: ""
        val bookmarkLabel = if (url.isNotBlank() && isBookmarked(url)) "Yer iminden kaldır" else "Yer imine ekle"
        popup.menu.add(0, 1, 0, "Sesle Ara")
        popup.menu.add(0, 2, 1, bookmarkLabel)
        popup.menu.add(0, 3, 2, "Yer İmleri")
        popup.menu.add(0, 4, 3, "Paylaş")
        popup.menu.add(0, 5, 4, "Maç Takip Et")
        popup.menu.add(0, 6, 5, "Ana Sayfa")
        popup.menu.add(0, 7, 6, "Geçmiş")
        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> onMicClicked()
                2 -> currentTab()?.let { toggleBookmark(it.url, it.title) }
                3 -> showBookmarksDialog()
                4 -> shareCurrentPage()
                5 -> showFollowDialog()
                6 -> currentTab()?.webView?.loadUrl(HOME_URL)
                7 -> showHistoryDialog()
            }
            true
        }
        popup.show()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    @Suppress("MissingSuperCall", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val tab = currentTab()
        if (tab != null && tab.webView.canGoBack()) {
            tab.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
