package com.evoragx.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MatchCheckWorker(appContext: Context, params: WorkerParameters) : Worker(appContext, params) {

    companion object {
        const val CHANNEL_ID = "evora_match_channel"
        const val PREFS_NAME = "evora_match_follow"
    }

    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val teamName = prefs.getString("team_name", null) ?: return Result.success()

        try {
            val teamId = findTeamId(teamName) ?: return Result.success()
            checkEvents(teamId, prefs)
            return Result.success()
        } catch (e: Exception) {
            return Result.retry()
        }
    }

    private fun httpGet(urlStr: String): String {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        val text = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()
        return text
    }

    private fun findTeamId(teamName: String): String? {
        val encoded = URLEncoder.encode(teamName, "UTF-8")
        val json = JSONObject(httpGet("https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t=$encoded"))
        val teams = json.optJSONArray("teams") ?: return null
        if (teams.length() == 0) return null
        return teams.getJSONObject(0).optString("idTeam", null)
    }

    private fun checkEvents(teamId: String, prefs: android.content.SharedPreferences) {
        // Son oynanan mac (skor icin)
        val lastJson = JSONObject(httpGet("https://www.thesportsdb.com/api/v1/json/3/eventslast.php?id=$teamId"))
        val lastEvents = lastJson.optJSONArray("results")
        if (lastEvents != null && lastEvents.length() > 0) {
            val event = lastEvents.getJSONObject(0)
            val eventId = event.optString("idEvent")
            val home = event.optString("strHomeTeam")
            val away = event.optString("strAwayTeam")
            val homeScore = event.optString("intHomeScore", "")
            val awayScore = event.optString("intAwayScore", "")
            val scoreKey = "$eventId:$homeScore-$awayScore"

            val lastSeenScoreKey = prefs.getString("last_score_key", "")
            if (homeScore.isNotEmpty() && awayScore.isNotEmpty() && scoreKey != lastSeenScoreKey) {
                sendNotification("Skor güncellendi", "$home $homeScore - $awayScore $away")
                prefs.edit().putString("last_score_key", scoreKey).apply()
            }
        }

        // Bugun/yaklasan mac (baslangic bildirimi icin)
        val nextJson = JSONObject(httpGet("https://www.thesportsdb.com/api/v1/json/3/eventsnext.php?id=$teamId"))
        val nextEvents = nextJson.optJSONArray("events")
        if (nextEvents != null && nextEvents.length() > 0) {
            val event = nextEvents.getJSONObject(0)
            val eventId = event.optString("idEvent")
            val dateEvent = event.optString("dateEvent")
            val home = event.optString("strHomeTeam")
            val away = event.optString("strAwayTeam")

            val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            val lastNotifiedMatchId = prefs.getString("last_notified_start_id", "")
            if (dateEvent == today && eventId != lastNotifiedMatchId) {
                sendNotification("Maç bugün!", "$home - $away bugün oynanıyor")
                prefs.edit().putString("last_notified_start_id", eventId).apply()
            }
        }
    }

    private fun sendNotification(title: String, message: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Maç Bildirimleri", NotificationManager.IMPORTANCE_HIGH)
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .build()

        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.TIRAMISU ||
            androidx.core.content.ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(applicationContext).notify(System.currentTimeMillis().toInt(), notification)
        }
    }
}
